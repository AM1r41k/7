﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace AutoLevelHometask
{
    class Program
    {
        static void Main(string[] args)
        {
            var dataSet = new DataSet("ShopDb");
            var dataAdapter = new SqlDataAdapter("Select * from Employees", "Data Source=DESKTOP-H5GCVAL;Initial Catalog=ShopDb;Integrated Security=True");
            dataAdapter.Fill(dataSet);

            var employeeTable = dataSet.Tables.Add("Employees");
            var employeeIdColumn = new DataColumn("id", typeof(int));
            employeeIdColumn.ReadOnly = true;
            employeeIdColumn.AllowDBNull = false;
            employeeIdColumn.AutoIncrement = true;
            employeeIdColumn.AutoIncrementSeed = 0;
            employeeIdColumn.AutoIncrementStep = 1;

            var employeeName = new DataColumn("Name", typeof(string));

            employeeTable.Columns.AddRange(new DataColumn[] { employeeIdColumn, employeeName });

            var newRow = employeeTable.NewRow();
           
            newRow.ItemArray = new object[] { 3, "Анатолий" };
            employeeTable.Rows.Add(newRow);

            employeeTable.PrimaryKey = new DataColumn[] { employeeIdColumn };

            var customersTable = dataSet.Tables.Add("Customers");
            var customersIdColumn = new DataColumn("id", typeof(int));
            customersIdColumn.ReadOnly = true;
            customersIdColumn.AllowDBNull = false;
            customersIdColumn.AutoIncrement = true;
            customersIdColumn.AutoIncrementSeed = 0;
            customersIdColumn.AutoIncrementStep = 1;

            var customerName = new DataColumn("Name", typeof(string));

            customersTable.Columns.AddRange(new DataColumn[] { customersIdColumn, customerName });
            customersTable.PrimaryKey = new DataColumn[] { customersIdColumn };

            var productsTable = dataSet.Tables.Add("Products");
            var productsIdColumn = new DataColumn("id", typeof(int));
            productsIdColumn.ReadOnly = true;
            productsIdColumn.AllowDBNull = false;
            productsIdColumn.AutoIncrement = true;
            productsIdColumn.AutoIncrementSeed = 0;
            productsIdColumn.AutoIncrementStep = 1;
            var productName = new DataColumn("Name", typeof(string));
            var productPrice = new DataColumn("Price", typeof(int));
            productsTable.Columns.AddRange(new DataColumn[] { productsIdColumn, productName, productPrice });

            productsTable.PrimaryKey = new DataColumn[] { productsIdColumn };

            var ordersTable = dataSet.Tables.Add("Orders");
            var ordersIdColumn = new DataColumn("id", typeof(int));
            ordersIdColumn.ReadOnly = true;
            ordersIdColumn.AllowDBNull = false;
            ordersIdColumn.AutoIncrement = true;
            ordersIdColumn.AutoIncrementSeed = 0;
            ordersIdColumn.AutoIncrementStep = 1;

            var productId = new DataColumn("productId", typeof(int));
            var customerId = new DataColumn("customerId", typeof(int));

            ordersTable.Columns.AddRange(new DataColumn[] { ordersIdColumn, productId, customerId });
            ordersTable.PrimaryKey = new DataColumn[] { ordersIdColumn };  

            var orderDetailsTable = dataSet.Tables.Add("OrderDetails");
            var orderDetailsIdColumn = new DataColumn("id", typeof(int));
            orderDetailsIdColumn.ReadOnly = true;
            orderDetailsIdColumn.AllowDBNull = false;
            orderDetailsIdColumn.AutoIncrement = true;
            orderDetailsIdColumn.AutoIncrementSeed = 0;
            orderDetailsIdColumn.AutoIncrementStep = 1;

            var orderDescription = new DataColumn("orderDescription", typeof(string));

            orderDetailsTable.Columns.AddRange(new DataColumn[] { orderDetailsIdColumn, orderDescription });

            orderDetailsTable.PrimaryKey = new DataColumn[] { orderDetailsIdColumn };

            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            dataAdapter.Update(dataSet);
            dataSet.AcceptChanges();
        }
    }
}
